import { LightningElement, wire, track, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import getKnowledgeArticle from '@salesforce/apex/KnowledgeController.getKnowledgeArticle';
// import getKnowledgeCategory from '@salesforce/apex/KnowledgeController.getKnowledgeCategory';
import upsertKnowledgeCategory from '@salesforce/apex/KnowledgeController.upsertKnowledgeCategory';
// UI API approach is giving inconsistent results for knowledge articles
// import { getRecord } from 'lightning/uiRecordApi';

export default class KnowledgeArticleCategory extends LightningElement {

    @api recordId;
    knowledgeCategory = {};
    isEditable = false;
    showReadOnlyMsg = false;
    categoriesSelectionDetails={};
    @track knowledgeCategoryAvailable =false;

    updateSelectedRows(e) {
        debugger;
        console.log('>>> Parent Detail' + e.detail);
        this.categoriesSelectionDetails = e.detail;
    }

    async handleSave() {
        try {
            var categories =  JSON.stringify(this.categoriesSelectionDetails);
            let resultObj = await upsertKnowledgeCategory({ knowledgeId: this.recordId, categoriesDetials: categories});
            this.knowledgeCategory = resultObj;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Knowledge article Categories updated',
                    variant: 'success'
                })
            );
        } catch (err) {
            console.log(err);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error while saving knowledge article',
                    message: err.message,
                    variant: 'error'
                })
            );
        }
    }

    renderedCallback() {
        this.isEditable = true;
        this.showReadOnlyMsg = !this.isEditable;
    }
}