import { LightningElement, api, wire,track } from 'lwc';
import { loadScript, loadStyle } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecord } from 'lightning/uiRecordApi';
import getCategoryList from '@salesforce/apex/KnowledgeController.getCategoryList';
import getKnowledgeArticle from '@salesforce/apex/KnowledgeController.getKnowledgeArticle';
const DELAY = 350;
const defaultColumns = [
    {
        type: 'text',
        fieldName: 'Name',
        label: 'Categories', 
    }
]
const SELECTED_ROW_EVENT = "selectedrowevent";

export default class KnowledgeCategory extends LightningElement {
    @api categoryList;
    @api recordId;
    @api isEditable;
    @track categoryListHirerachy;
    @track selectedRows = [];
    @track unSelectedRows = [];
    @track currentSelectedRows;
    selectedKcadded = false;
    // definition of columns for the tree grid
    gridColumns = defaultColumns;
    gridData;
    knowledgeObj;
    knowledgeCategory;

    //Apex call to get list of all Categories
    @wire(getCategoryList)
    wiredResponse({ data, error }) {
        debugger;
        if (data) {
            this.categoryList = JSON.parse(JSON.stringify(data));
            debugger;         
            this.createGridData(this.categoryList);
            //Expand all by default
            console.log("categoryListHirerachy.." + JSON.stringify(this.categoryListHirerachy )); 
        } else if (error) {
            this.knowledgeObj = undefined;
            console.log(error);
        }
    }

    //Use the Data from Apex call to generate Tree Grid for the component
    createGridData(categoryList){
        this.gridData = JSON.parse(JSON.stringify(this.generateTreeGridData(categoryList)));
    }

    //Recursively navigate through each node to generate the tree grid
    generateTreeGridData(categoryList){
        const hashTable = Object.create(null);
        categoryList.forEach(aData => hashTable[aData.Id] = {...aData, _children: []});
        const dataTree = [];
        categoryList.forEach(aData => {
            if(aData.ParentCategory__c) hashTable[aData.ParentCategory__c]._children.push(hashTable[aData.Id])
            else dataTree.push(hashTable[aData.Id])
        });
        console.log(JSON.stringify(dataTree));
        return dataTree;
    }

    renderedCallback() {
        debugger;
        this.expandAll();
        if(!this.selectedKcadded){
            //Apex call to get KnowledgeObject data and the associated KnowledgeArticleCategories.
            getKnowledgeArticle({ knowledgeId: this.recordId}).then((result) => {
                if (result) {
                    result = JSON.parse(result);
                    this.knowledgeObj = result.knowledgeObj;
                    this.knowledgeCategory= result.knowledgeCategory;
                    console.log("knowledgeObj.." + JSON.parse(JSON.stringify(this.knowledgeObj )));
                    console.log("knowledgeCategoryList.." + JSON.parse(JSON.stringify(this.knowledgeCategory)));
                    if(this.knowledgeCategory!== undefined && this.knowledgeCategory.length > 0){
                        this.selectedRows = this. getSelectedCategories(this.knowledgeCategory);
                        this.selectedKcadded = true;
                    }
                } else if (error) {
                    this.knowledgeObj = undefined;
                    console.log(error);
                }
                
            });
        }
        this.knowledgeCategory = resultObj;
        console.log("selectedRows..." + JSON.parse(JSON.stringify(this.selectedRows)));
        console.log("columns..." + JSON.parse(JSON.stringify(columns)));
        console.log("knowledgeObj..." + JSON.parse(JSON.stringify(knowledgeObj)));
        console.log("knowledgeCategory.." + JSON.parse(JSON.stringify(knowledgeCategoryList)));

    }

    //Preselect saved Data catefories in the component
    getSelectedCategories(knowledgeCategory){
        var tempList = [];
        knowledgeCategory.forEach(record => {
            tempList.push(record.CategoryId__c);
        })
        return tempList;
    }

    //Expand all by default
    expandAll() {
        const grid =  this.template.querySelector('lightning-tree-grid');
        grid.expandAll();
    }

    updateSelectedRows() {
        var tempList = [];
        var selectRows = this.template.querySelector('lightning-tree-grid').getSelectedRows();
        if(selectRows.length > 0){
            selectRows.forEach(record => {
                tempList.push(record.Id);
            })

            tempList = this.handleChildSelection(this.gridData, tempList);

            this.selectedRows = tempList;
            this.currentSelectedRows = tempList;
            const categoriesSelectionDetails = {
                selectedRows: this.selectedRows,
                unSelectedRows: this.unSelectedRows
            }
            const selectedRowEvent = new CustomEvent(SELECTED_ROW_EVENT,{detail:categoriesSelectionDetails} );
            this.dispatchEvent(selectedRowEvent);
        }
    }

    handleChildSelection(categoriesList, tempList){
        categoriesList.forEach(record => {
            if( tempList.includes(record.Id)) {
                record._children.forEach(item => {
                    if(this.currentSelectedRows !== undefined && this.currentSelectedRows.includes(item.Id) && !tempList.includes(item.Id)) { 
                        const index = tempList.indexOf(item.Id);
                        if(index > -1) {
                            tempList.splice(index, 1);
                            this.unSelectedRows.push(item.Id);
                        }
                    }
                    else if(!tempList.includes(item.Id)) {
                        tempList.push(item.Id);
                    }
                })
            }

            else{
                this.handleChildSelection( record._children, tempList)
            }
        })
        return tempList;

    }

    getSelectedCategories(knowledgeCategoryList){
        var tempList = [];
        knowledgeCategoryList.forEach(record => {
            tempList.push(record.CategoryId__c);
        })
        return tempList;
    }

}