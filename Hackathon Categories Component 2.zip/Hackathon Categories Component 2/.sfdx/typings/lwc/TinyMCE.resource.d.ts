declare module "@salesforce/resourceUrl/TinyMCE" {
    var TinyMCE: string;
    export default TinyMCE;
}