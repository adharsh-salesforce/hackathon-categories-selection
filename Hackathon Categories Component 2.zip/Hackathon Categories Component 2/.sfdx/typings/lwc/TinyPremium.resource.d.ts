declare module "@salesforce/resourceUrl/TinyPremium" {
    var TinyPremium: string;
    export default TinyPremium;
}