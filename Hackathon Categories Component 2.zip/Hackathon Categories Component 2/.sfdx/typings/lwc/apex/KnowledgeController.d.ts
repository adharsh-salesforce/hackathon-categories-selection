declare module "@salesforce/apex/KnowledgeController.getKnowledgeArticle" {
  export default function getKnowledgeArticle(param: {knowledgeId: any}): Promise<any>;
}
declare module "@salesforce/apex/KnowledgeController.getKnowledgeCategory" {
  export default function getKnowledgeCategory(param: {knowledgeId: any}): Promise<any>;
}
declare module "@salesforce/apex/KnowledgeController.getCategoryList" {
  export default function getCategoryList(): Promise<any>;
}
declare module "@salesforce/apex/KnowledgeController.upsertKnowledgeCategory" {
  export default function upsertKnowledgeCategory(param: {knowledgeId: any, categoriesDetials: any}): Promise<any>;
}
